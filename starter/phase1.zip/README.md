# Phase 1

Empty starting project so you can follow along with the [tutorial on Meduim](https://medium.com/@dane.mackier/breaking-down-tiktoks-ui-using-flutter-8489fe4ad944)
